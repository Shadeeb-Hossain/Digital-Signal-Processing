% Name : Shadeeb Hossain 

% Loading the file 
[y, Fs] = audioread('part_a.wav');

% Computing the Discrete Fourier Transform (DFT) 
Y = (fft(y));

% Frequency axis
N = length(Y);
f = linspace(-Fs/2, Fs/2, N);

% Plot the DTFT
figure (1);
subplot(2,1,1);
plot(f, abs(Y));
title('DTFT of the Speech Segment');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;

% Zoom in on the main part of the spectrum
subplot(2,1,2);
plot(f, abs(Y));
title('Zoomed / Magnified DTFT of the Speech Segment');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([10000, 15000]); % Adjust the limits based on your signal
grid on;

%% Trying the fftshift function 
segment_start = 10000;
segment_length = 15000; 
segment = y(segment_start : segment_start + segment_length - 1);

% Discrete Fourier Transform (DFT) using FFT
Y_shift = fftshift(fft(segment));

% Frequency axis
N_1 = length(Y_shift);
f_1 = linspace(-Fs/2, Fs/2, N_1);
% Ploting the graph 

figure (2)
plot(f_1, abs(Y_shift));
title('DTFT of the Speech Segment');
xlabel('Frequency (Hz)');
ylabel('Magnitude');

